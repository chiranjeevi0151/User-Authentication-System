# config.py

# Secret key for potential future expansions like token-based authentication
SECRET_KEY = "your_secret_key_here"  # Replace with a secure key in a real deployment
            